#/* Copyright (C) 2002-2009 Proguru. 
#   changuoqiang[at]gmail[dot]com
#   http://blog.pcware.cn
#
#   The Source Code is free; you can redistribute it and/or
#   modify it under the terms of the GNU Lesser General Public
#   License as published by the Free Software Foundation; either
#   version 2.1 of the License, or (at your option) any later version.
#
#   The Source Code is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#   Lesser General Public License for more details.
#
#   You should have received a copy of the GNU Lesser General Public
#   License along with the KWinUI; if not, write to the Free
#   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#   02111-1307 USA.  */
#
#/*
# *  Jun 14,2009    
# */

use Encode;

sub ipwhere{
	my $ip      = shift;
	my @ip      = split(/\./, $ip);
	my $ip_num  = $ip[0]*256**3 + $ip[1]*256**2 + $ip[2]*256 + $ip[3];

    #my $qqwry_dat="${DIR}/plugins/QQWry.Dat";
	my $qqwry_dat = "/usr/local/share/ip_geo/QQWry.Dat";
	open(INFILE, "$qqwry_dat");
	binmode(INFILE);

	my $first_index_of_begin_ip, $last_index_of_begin_ip;
	sysread(INFILE, $first_index_of_begin_ip, 4);
	sysread(INFILE, $last_index_of_begin_ip, 4);

	$first_index_of_begin_ip    = unpack("L",$first_index_of_begin_ip);
	$last_index_of_begin_ip     = unpack("L",$last_index_of_begin_ip);
	my $total_index_of_begin_ip = ($last_index_of_begin_ip - $first_index_of_begin_ip)/7 + 1;

    #binary search the begin ip
    my $begin_index, $end_index = $total_index_of_begin_ip;
    my $middle_index, $middle_ip, $middle_ip_num;

#    while(1){
#        if($begin_index >= $end_index-1){
#            last;
#        }
#        $middle_index = int(($end_index + $begin_index)/2); 
#        seek(INFILE, $first_index_of_begin_ip + $middle_index*7, 0);
#        read(INFILE, $middle_ip, 4);
#        $middle_ip_num = unpack("L", $middle_ip);
#        if($ip_num < $middle_ip_num){
#            $end_index = $middle_index ;
#        } else {
#            $begin_index = $middle_index ;
#        }
#    }

    while($begin_index < ($end_index -1) ){

        $middle_index = int (($end_index + $begin_index)/2); 
        seek(INFILE, $first_index_of_begin_ip + 7*$middle_index, 0);
        read(INFILE, $middle_ip, 4);
        $middle_ip_num = unpack("L", $middle_ip);

        if($ip_num == $middle_ip_num){
            $begin_index = $middle_index;
            last;
        } elsif ($ip_num < $middle_ip_num){
            $end_index = $middle_index;
        } else {
            $begin_index = $middle_index;
        }
    }

    my $end_ip_index_offset, $end_ip, $end_ip_num, $end_ip_offset;
    $end_ip_index_offset = $first_index_of_begin_ip + 7*($begin_index) + 4;
    seek(INFILE, $end_ip_index_offset, 0);
    read(INFILE, $end_ip_offset, 3);
    
    $end_ip_offset = unpack("L", $end_ip_offset."\0");
    seek(INFILE, $end_ip_offset, 0);
    read(INFILE, $end_ip, 4);
    $end_ip_num = unpack("L", $end_ip);

    if($ip_num <= $end_ip_num){
        my $offset, $position_mode, $geo_country_mode_2_pos=0;

        $/="\0";
        read(INFILE,$position_mode,1);

        #position mode 1   
        if ($position_mode eq "\1") {
            read(INFILE,$offset,3);
            $offset = unpack("L",$offset."\0");
            seek(INFILE,$offset,0);
            read(INFILE,$position_mode,1);
        }
        #position mode 2
        if ($position_mode eq "\2") {
            read(INFILE,$offset,3);
            $geo_country_mode_2_pos = tell(INFILE);
            $offset = unpack("L",$offset."\0");
            seek(INFILE,$offset,0);
        } else {
            seek(INFILE,-1,1);
        }
        $ip_geo_country=<INFILE>;

        if($geo_country_mode_2_pos != 0){
            seek(INFILE, $geo_country_mode_2_pos, 0);
        }

        #geo local, geo local only position mode 2
        read(INFILE,$position_mode,1);
        if($position_mode eq "\2") {
            read(INFILE,$offset,3);
            $offset = unpack("L",$offset."\0");
            seek(INFILE,$offset,0);
        } else {
            seek(INFILE,-1,1);
        }
        $ip_geo_local=<INFILE>;
    } else{
        $ip_geo_country = "δ֪����";
    }

	chomp($ip_geo_country, $ip_geo_local);
	$/="\n";
	close(INFILE);
	
	my $ip_geo_addr="$ip_geo_country $ip_geo_local";
	$ip_geo_addr =~ s/CZ88\.NET//isg;
    $ip_geo_addr=decode("gbk",$ip_geo_addr);

	return $ip_geo_addr;
}

1;
