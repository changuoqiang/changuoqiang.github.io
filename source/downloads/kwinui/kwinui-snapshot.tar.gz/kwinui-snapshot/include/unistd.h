/** 
 *  unistd.h maps     (roughly) to io.h
 */

#ifndef __UNISTD_H__
#define __UNISTD_H__

#include <io.h>
#include <process.h>

#endif //__UNISTD_H__
