#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DLG_MAIN                            100
