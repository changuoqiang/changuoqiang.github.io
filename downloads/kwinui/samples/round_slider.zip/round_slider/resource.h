#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DLG_ROUND_SLIDER                    100
#define IDC_SLIDER1                             1002
#define IDC_SLIDER2                             1003
